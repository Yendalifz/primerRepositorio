from Ahorcado import Ahorcado
def main ():
    juegoAhor= Ahorcado()
    juegoAhor.inicio()
main()
    